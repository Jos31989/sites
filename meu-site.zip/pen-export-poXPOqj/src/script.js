document.addEventListener('DOMContentLoaded', function() {
    // Adicione interatividade aqui, se necessário
});
